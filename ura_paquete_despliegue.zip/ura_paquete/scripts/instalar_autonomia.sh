#!/bin/bash
# instalar_autonomia.sh — Instala el módulo de Autonomía Avanzada
# Adapta rutas y servicios para macOS (launchd) y Linux (systemd).

set -euo pipefail

URA_BASE="$(cd "$(dirname "$0")/.." && pwd)"
VENV="$URA_BASE/.venv"

log() {
    echo "[$(date '+%H:%M:%S')] $*"
}

log "=== Instalando Autonomía Avanzada ==="
log "URA_BASE=$URA_BASE"

# 1. Dependencias Python
log "1. Instalando dependencias..."
source "$VENV/bin/activate" 2>/dev/null || { log "ERROR: venv no encontrado"; exit 1; }
pip install -q requests psutil opencv-python numpy pyautogui pytesseract 2>/dev/null || true
log "   pip OK"

# deepface y flask son opcionales (solo si se usa API standalone)
pip install -q deepface flask 2>/dev/null || log "   deepface/flask no instalados (opcionales)"

# 2. Tesseract (macOS: brew, Linux: apt)
if [[ "$OSTYPE" == "darwin"* ]]; then
    if command -v brew &>/dev/null; then
        brew install tesseract tesseract-lang 2>/dev/null || log "   tesseract ya instalado"
    fi
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    if command -v apt-get &>/dev/null; then
        sudo apt-get install -y tesseract-ocr tesseract-ocr-spa 2>/dev/null || log "   tesseract ya instalado"
    fi
fi

# 3. Configurar reglas legales por defecto
log "2. Configurando reglas legales..."
mkdir -p "$URA_BASE/config"
if [[ ! -f "$URA_BASE/config/legal_rules.json" ]]; then
    cat > "$URA_BASE/config/legal_rules.json" <<'EOF'
{
  "invitacion_no_cobrada": {"max_euros": 10, "escalar_si_cliente_no_habitual": true},
  "despido_empleado": {"automatico": false, "escalar_siempre": true},
  "tiempo_descanso_excesivo": {"minutos_max": 30, "accion": "notificar"}
}
EOF
    log "   legal_rules.json creado"
else
    log "   legal_rules.json ya existe"
fi

# 4. Configurar config de autonomía
if [[ ! -f "$URA_BASE/config/autonomia.json" ]]; then
    python3 -c "
import json, sys
sys.path.insert(0, '$URA_BASE')
from agents.autonomia_avanzada import DEFAULT_CONFIG
with open('$URA_BASE/config/autonomia.json', 'w') as f:
    json.dump(DEFAULT_CONFIG, f, indent=2)
" 2>/dev/null || log "   autonomia.json se creara en primer uso"
fi

# 5. Servicio (macOS launchd / Linux systemd)
if [[ "$OSTYPE" == "darwin"* ]]; then
    log "3. Configurando launchd (macOS)..."
    VENV_PY="$VENV/bin/python3"
    cat > ~/Library/LaunchAgents/com.ura.autonomia.plist <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.ura.autonomia</string>
    <key>WorkingDirectory</key>
    <string>$URA_BASE</string>
    <key>ProgramArguments</key>
    <array>
        <string>$VENV_PY</string>
        <string>$URA_BASE/agents/autonomia_avanzada.py</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>/tmp/autonomia.log</string>
    <key>StandardErrorPath</key>
    <string>/tmp/autonomia_error.log</string>
</dict>
</plist>
EOF
    launchctl unload ~/Library/LaunchAgents/com.ura.autonomia.plist 2>/dev/null || true
    launchctl load ~/Library/LaunchAgents/com.ura.autonomia.plist
    log "   launchd configurado"

elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    log "3. Configurando systemd (Linux)..."
    if command -v systemctl &>/dev/null; then
        VENV_PY="$VENV/bin/python3"
        sudo tee /etc/systemd/system/ura-autonomia.service > /dev/null <<EOF
[Unit]
Description=URA Autonomia Avanzada
After=network.target

[Service]
ExecStart=$VENV_PY $URA_BASE/agents/autonomia_avanzada.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
        sudo systemctl daemon-reload
        sudo systemctl enable ura-autonomia.service
        sudo systemctl start ura-autonomia.service
        log "   systemd configurado"
    else
        log "   systemd no disponible"
    fi
fi

# 6. Cron para ciclo autónomo (cada 10 min)
log "4. Configurando cron..."
CRON_ENTRY="*/10 * * * * cd $URA_BASE && source $VENV/bin/activate && python3 -c 'from agents.autonomia_avanzada import AutonomiaExtendida; AutonomiaExtendida().ejecutar_ciclo_autonomo()'"
if ! crontab -l 2>/dev/null | grep -q "autonomia_avanzada"; then
    (crontab -l 2>/dev/null; echo "$CRON_ENTRY") | crontab -
    log "   Cron añadido"
else
    log "   Cron ya existe"
fi

# 7. Verificar Laia API
log "5. Verificando Laia API..."
sleep 2
if curl -s --fail --max-time 5 http://localhost:8000/health > /dev/null 2>&1; then
    log "   Laia API responde"
else
    log "   Laia API no responde (puede arrancar mas tarde)"
fi

log "=== Instalación completada ==="
log "API autonomia en puerto 5105 (si se ejecuta como servicio)"
log "Logs: tail -f /tmp/autonomia.log"
