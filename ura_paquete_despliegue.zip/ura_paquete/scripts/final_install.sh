#!/bin/bash
# final_install.sh — Despliegue final de todos los componentes de Laia
# Configura servicios, cron, y verificación de autonomía.

set -euo pipefail

URA_BASE="$(cd "$(dirname "$0")/.." && pwd)"
VENV="$URA_BASE/.venv"
VENV_PY="$VENV/bin/python3"
VENV_UVICORN="$VENV/bin/uvicorn"

log() {
    echo "[$(date '+%H:%M:%S')] $*"
}

log "=== Despliegue final de Laia ==="
log "URA_BASE=$URA_BASE"

# 1. Verificar dependencias
log "1. Verificando dependencias..."
source "$VENV/bin/activate" 2>/dev/null || { log "ERROR: venv no encontrado en $VENV"; exit 1; }
pip install -q fastapi uvicorn pydantic 2>/dev/null || true
log "   Dependencias OK"

# 2. Crear directorios necesarios
log "2. Creando directorios..."
mkdir -p "$URA_BASE/logs" "$URA_BASE/macros" "$URA_BASE/scripts/memoria"
log "   Directorios OK"

# 3. Configurar permisos
log "3. Configurando permisos..."
chmod +x "$URA_BASE/orquestador/laia_bridge.sh"
chmod +x "$URA_BASE/scripts/auto_heal_laia.sh"
chmod +x "$URA_BASE/core/autonomous_loop.py"
log "   Permisos OK"

# 4. Instalar servicios (macOS launchd)
if [[ "$OSTYPE" == "darwin"* ]]; then
    log "4. Instalando servicios launchd (macOS)..."

    # Laia API
    cat > ~/Library/LaunchAgents/com.ura.laia.api.plist <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.ura.laia.api</string>
    <key>WorkingDirectory</key>
    <string>$URA_BASE</string>
    <key>ProgramArguments</key>
    <array>
        <string>$VENV_PY</string>
        <string>-m</string>
        <string>uvicorn</string>
        <string>laia_api:app</string>
        <string>--host</string>
        <string>0.0.0.0</string>
        <string>--port</string>
        <string>8000</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>/tmp/laia_api.log</string>
    <key>StandardErrorPath</key>
    <string>/tmp/laia_api_error.log</string>
</dict>
</plist>
EOF

    # Laia Autonomous Loop
    cat > ~/Library/LaunchAgents/com.ura.laia.autonomous.plist <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.ura.laia.autonomous</string>
    <key>WorkingDirectory</key>
    <string>$URA_BASE</string>
    <key>ProgramArguments</key>
    <array>
        <string>$VENV_PY</string>
        <string>$URA_BASE/core/autonomous_loop.py</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>/tmp/laia_autonomous.log</string>
    <key>StandardErrorPath</key>
    <string>/tmp/laia_autonomous_error.log</string>
</dict>
</plist>
EOF

    launchctl unload ~/Library/LaunchAgents/com.ura.laia.api.plist 2>/dev/null || true
    launchctl unload ~/Library/LaunchAgents/com.ura.laia.autonomous.plist 2>/dev/null || true
    launchctl load ~/Library/LaunchAgents/com.ura.laia.api.plist
    launchctl load ~/Library/LaunchAgents/com.ura.laia.autonomous.plist
    log "   Servicios launchd instalados"

elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    log "4. Instalando servicios systemd (Linux)..."

    if command -v systemctl &>/dev/null; then
        sudo tee /etc/systemd/system/laia-api.service > /dev/null <<EOF
[Unit]
Description=Laia AI Agent API
After=network.target

[Service]
ExecStart=$VENV_UVICORN laia_api:app --host 0.0.0.0 --port 8000
WorkingDirectory=$URA_BASE
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

        sudo tee /etc/systemd/system/laia-autonomous.service > /dev/null <<EOF
[Unit]
Description=Laia Autonomous Loop
After=laia-api.service

[Service]
ExecStart=$VENV_PY $URA_BASE/core/autonomous_loop.py
WorkingDirectory=$URA_BASE
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

        sudo systemctl daemon-reload
        sudo systemctl enable laia-api.service
        sudo systemctl enable laia-autonomous.service
        sudo systemctl start laia-api.service
        sudo systemctl start laia-autonomous.service
        log "   Servicios systemd instalados"
    else
        log "   systemd no disponible, saltando"
    fi
fi

# 5. Configurar auto_heal en crontab
log "5. Configurando auto_heal en crontab..."
CRON_ENTRY="*/5 * * * * $URA_BASE/scripts/auto_heal_laia.sh"
if ! crontab -l 2>/dev/null | grep -q "auto_heal_laia"; then
    (crontab -l 2>/dev/null; echo "$CRON_ENTRY") | crontab -
    log "   Cron añadido"
else
    log "   Cron ya existe"
fi

# 6. Integrar Laia bridge con Tuneladora
log "6. Verificando bridge Laia↔Tuneladora..."
if [[ -f "$URA_BASE/orquestador/laia_bridge.sh" ]]; then
    log "   Bridge presente"
else
    log "   ERROR: Bridge no encontrado"
    exit 1
fi

# 7. Esperar y verificar
log "7. Esperando 5s para que los servicios arranquen..."
sleep 5

log "=== Verificación final ==="
if curl -s --fail --max-time 5 http://localhost:8000/health > /dev/null 2>&1; then
    log "✅ Laia API responde"
else
    log "⚠️  Laia API no responde (puede tardar unos segundos en arrancar)"
fi

if curl -s --fail --max-time 5 http://127.0.0.1:5103/health > /dev/null 2>&1; then
    log "✅ Tuneladora health responde"
else
    log "⚠️  Tuneladora health no responde"
fi

log "=== Instalación completada ==="
log "Comandos útiles:"
log "  curl http://localhost:8000/health"
log "  source $URA_BASE/orquestador/laia_bridge.sh && laia_command 'hola'"
log "  tail -f /tmp/laia_autonomous.log"
