# URA / Laia — Sistema de Autonomía Avanzada para Hostelería

Sistema de IA autónomo (Nivel 3) para gestión de bares. Cubre 11 reglas de negocio, autocuración de red, planificación LLM, visión de pantalla y control por voz.

## 📦 Estructura
```
├── core/                    # Motor Laia (seguridad, ejecución, planificación, riesgo)
├── agents/                  # Agentes (Laia principal, puente Tuneladora, autonomía 11 reglas)
├── orquestador/             # Coordinación Enjambre (bridge, meta-aprendizaje)
├── scripts/                 # Despliegue y mantenimiento (install, heal, network repair, 4G)
├── config/                  # Reglas legales, config Laia, config autonomía
├── laia_api.py              # API FastAPI (puerto 8000)
└── tests/                   # 44 tests unitarios
```

## 🚀 Despliegue Rápido
```bash
# 1. Copiar a /opt/ura y dar permisos
sudo cp -r * /opt/ura/
cd /opt/ura
chmod +x scripts/*.sh

# 2. Instalar (macOS o Linux)
./scripts/final_install.sh
sudo ./scripts/instalar_autonomia.sh

# 3. Módem 4G (solo Linux GX10)
sudo ./scripts/instalar_modem_4g.sh

# 4. Verificar
curl http://localhost:8000/health
curl http://localhost:5105/health
```

## 🧠 Comandos de Voz
Di **"URA"** para activar, luego:
- *"Repara la red"* → Autocuración de red
- *"Lanza buzo buzo_red"* → Ejecutar buzo de la Tuneladora
- *"Analiza la limpieza de hoy"* → Regla 9
- *"Informe de mejora continua"* → Regla 10
- *"Consumo de empleados"* → Regla 11

## 📋 Reglas de Negocio
1. **Invitaciones** (límite 8€, cliente habitual)
2. **Descansos** (15 min/día, recuperación)
3. **Tiempos atención** (medias móviles, alertas)
4. **Repartidores/Almacén** (horario 8-20, bloqueo puertas)
5. **Eficiencia operativa** (roturas, móvil, conversaciones)
6. **Coordinación** (salida platos, prioridad barra)
7. **Optimización personal** (predicción carga TPV)
8. **Calendario/Meteo** (planificación 7 días)
9. **Limpieza/Rutinas** (franjas horarias, consumos indebidos)
10. **Mejora continua** (detección comportamientos nuevos, autoajuste)
11. **Consumo empleados** (límites café/refresco, alcohol prohibido)

## 🔧 Autocuración de Red
- **Nivel 1:** Reinicio interfaz Wi-Fi/eth0
- **Nivel 2:** Reinicio servicios de red
- **Nivel 3:** Fallback módem 4G (Linux)
- **Nivel 4:** Reboot del sistema

## 📞 Soporte
- Logs: `/tmp/laia_autonomous.log`, `/tmp/autonomia.log`, `/tmp/ura_network_autorepair.log`
- Plan de supervivencia: `docs/PLAN_SUPERVIVENCIA.md`
