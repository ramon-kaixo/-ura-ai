import json
import logging
import os
import subprocess
import time
from typing import Any

import numpy as np

from core.safety import Safety
from core.action_executor import ActionExecutor
from core.screen_reader import ScreenReader
from core.explorer import Explorer
from core.planner import TaskPlanner
from core.governance import Governance
from agents.laia_tuneladora_agent import TuneladoraBridge

logger = logging.getLogger(__name__)

FRIGATE_URL = os.getenv("FRIGATE_URL", "http://localhost:5000")
AUTONOMIA_URL = os.getenv("AUTONOMIA_URL", "http://localhost:5105")
MODEL_CODIFICACION = os.getenv("MODEL_CODIFICACION", "qwen3:32b")
GX10_URL = os.getenv("GX10_URL", "http://100.127.206.86:11434/api/chat")


class LaiaAgent:
    def __init__(self) -> None:
        self.safety = Safety()
        self.executor = ActionExecutor(self.safety)
        self.reader = ScreenReader(use_vlm=True)
        self.explorer = Explorer(self.executor, self.reader)
        self.planner = TaskPlanner()
        self.governance = Governance()
        self.tuneladora = TuneladoraBridge()
        self._stt_model: Any = None

    def _get_stt_model(self) -> Any:
        if self._stt_model is None:
            from faster_whisper import WhisperModel
            self._stt_model = WhisperModel("base", device="cpu", compute_type="int8")
        return self._stt_model

    def _stt(self, audio: np.ndarray) -> str:
        model = self._get_stt_model()
        segs, _ = model.transcribe(audio, language="es")
        return " ".join(s.text for s in segs).strip()

    def _tts(self, texto: str) -> None:
        subprocess.run(["say", texto], check=False)

    def process_command(self, natural_language_command: str) -> bool:
        cmd = natural_language_command.lower()
        if "lanza buzo" in cmd:
            buzo = cmd.split("lanza buzo")[-1].strip()
            result = self.tuneladora.lanzar_buzo(buzo)
            return result["returncode"] == 0
        if "reparar red" in cmd:
            result = self.call_autonomia("red/autorepair")
            return result.get("success", False)
        if "montar disco" in cmd or "montar backup" in cmd:
            result = self.call_autonomia("backup/mount")
            return result.get("success", False)
        if "limpieza" in cmd or "rutinas" in cmd:
            franja = "servicio_comidas" if "comidas" in cmd else "general"
            if "limpieza" in cmd:
                self.call_autonomia("limpieza/seguimiento", {"zona": franja})
            else:
                self.call_autonomia("limpieza/rutinas", {"franja": franja})
            return True
        if "mejora continua" in cmd or "comportamientos" in cmd:
            if "comportamientos" in cmd:
                self.call_autonomia("mejora/comportamientos")
            else:
                self.call_autonomia("mejora/informe")
            return True
        if "consumo" in cmd and "empleado" in cmd:
            self.call_autonomia("consumo/empleados", {"empleado_id": "general"})
            return True
        if "macro" in cmd and "aprender" in cmd:
            return self.explorer.learn_macro("ejemplo", cmd)
        if "macro" in cmd and "ejecutar" in cmd:
            return self.explorer.run_macro("ejemplo")
        if "clic en" in cmd:
            target = cmd.split("clic en")[-1].strip()
            bbox = self.reader.find_element_by_text(target)
            if bbox:
                cx = (bbox[0] + bbox[2]) // 2
                cy = (bbox[1] + bbox[3]) // 2
                self.executor.click(cx, cy)
                return True
        if "escribe" in cmd:
            text = cmd.split("escribe")[-1].strip()
            self.executor.write(text)
            return True
        return False

    def call_autonomia(self, endpoint: str, data: dict | None = None) -> dict:
        import requests

        url = f"{AUTONOMIA_URL}/{endpoint}"
        try:
            resp = requests.post(url, json=data, timeout=15)
            resp.raise_for_status()
            return resp.json()
        except Exception as exc:
            logger.error("Autonomia API fallo en %s: %s", endpoint, exc)
            return {"success": False, "error": str(exc)}

    def execute_planned_task(self, goal: str) -> bool:
        if self.governance.should_ask_human(goal):
            if not self.safety.confirm_action(f"Tarea de riesgo: {goal}. ¿Continuar?"):
                return False
        plan = self.planner.plan(goal)
        return self.planner.execute_plan(plan, self.executor, self.reader)

    def query_frigate_events(
        self,
        label: str = "person",
        after: int | None = None,
        before: int | None = None,
        zone: str | None = None,
    ) -> list[dict]:
        import requests

        url = f"{FRIGATE_URL}/api/events?label={label}"
        if after:
            url += f"&after={after}"
        if before:
            url += f"&before={before}"
        if zone:
            url += f"&zone={zone}"
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        events = resp.json()
        unique_ids = {e.get("id", "") for e in events}
        logger.info("Frigate: %d eventos, %d unicos", len(events), len(unique_ids))
        return [{"id": uid, "label": label} for uid in unique_ids]

    def run_repl(self) -> None:
        self._tts("Asistente iniciado. Diga URA para activar, salir para terminar.")
        print("Laia agent ready. Di 'URA' para activar, 'salir' para terminar.")
        import sounddevice as sd

        TASA = 16000
        while not self.safety.is_panic():
            print("   🎤 Escuchando...")
            audio = sd.rec(int(5 * TASA), samplerate=TASA, channels=1)
            sd.wait()
            audio = audio.flatten().astype(np.float32)
            texto = self._stt(audio)
            print(f"   📝 {texto}")
            if "ura" not in texto.lower():
                continue
            if "salir" in texto.lower():
                break
            self._tts("Que necesita")
            audio2 = sd.rec(int(6 * TASA), samplerate=TASA, channels=1)
            sd.wait()
            audio2 = audio2.flatten().astype(np.float32)
            orden = self._stt(audio2)
            if not orden:
                continue
            resultado = self.execute_planned_task(orden)
            self._tts("Hecho" if resultado else "No entendi")
