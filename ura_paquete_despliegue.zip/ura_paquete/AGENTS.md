# URA — AI Agent Instructions

## Project Context
URA is a multi-agent desktop assistant with specialized agents, a consciousness coordinator, a self-improving sandbox, and an autonomous swarm of research buzzers.

## Build & Test Commands
- Install: `pip install -r requirements.txt`
- Lint: `ruff check . && ruff format .`
- Test: `pytest tests/ -q`
- Full audit: `bash scripts/pro/tuneladora_pro.sh`
- Demo: `bash scripts/demo.sh`

## Architecture
- `core/` — Domain logic (consciousness, values, forensic scribe, rollback)
- `agents/` — Specialized agents (organized by domain in subdirectories for new additions)
- `adapters/` — External connectors (Ollama, messaging platforms)
- `knowledge/` — Long-term memory, document fragments, knowledge base
- `scripts/pro/` — Pro maintenance module (4 phases with snapshot + rollback)

## Naming Conventions
- Files: kebab-case for new files (e.g., `ura-panel.py`, `buzo-academico.sh`)
- Directories: kebab-case (e.g., `agents/cocina/`, `knowledge/fragmentos/`)
- Dates: ISO 8601 (YYYY-MM-DD)
- Artifacts: SLUG prefix (e.g., `audit-report-2026-05-17.md`)

## Security Rules
- No `shell=True` in subprocess calls
- No hardcoded secrets (use Boveda or environment variables)
- All autonomous changes go through sandbox + rollback
- Network allowlist for sandbox containers

## Code Style
- Ruff with ALL rules enabled
- Type hints required for all new functions
- Agent classes should inherit from existing base patterns
- Docstrings in Google style

## Key Files
- `AGENTS.md` — This file (AI instructions)
- `README.md` — Human-readable project overview
- `pyproject.toml` — Python project configuration
- `CLAUDE.md` — Symlink to AGENTS.md (Claude Code compatibility)
