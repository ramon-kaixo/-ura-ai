"""
Cerebro Semántico de URA — Memoria vectorial para manuales y experiencias.
Usa ChromaDB con embeddings locales vía Ollama (nomic-embed-text).
"""

import time
import os
import logging
from pathlib import Path

try:
    import chromadb
    from chromadb.utils import embedding_functions
except ImportError:
    chromadb = None
    embedding_functions = None

logger = logging.getLogger("SemanticBrain")


class SemanticBrain:
    def __init__(self, persist_path: str | None = None, ollama_url: str | None = None) -> None:
        if chromadb is None:
            raise ImportError("ChromaDB no instalado. Ejecuta: pip install chromadb")

        if persist_path is None:
            persist_path = str(Path(__file__).resolve().parent.parent.parent / "data" / "ura_vector_db")
        if ollama_url is None:
            ollama_url = os.getenv("OLLAMA_URL", "http://localhost:11434")

        self.client = chromadb.PersistentClient(path=persist_path)
        self.emb_fn = embedding_functions.OllamaEmbeddingFunction(
            url=ollama_url,
            model_name="nomic-embed-text",
        )
        self.collection_docs = self.client.get_or_create_collection(
            name="manuales",
            embedding_function=self.emb_fn,
            metadata={"hnsw:space": "cosine"},
        )
        self.collection_exp = self.client.get_or_create_collection(
            name="experiencias",
            embedding_function=self.emb_fn,
        )
        logger.info("SemanticBrain inicializado en %s", persist_path)

    def indexar_manual(self, app_name: str, texto_manual: str, seccion: str, id_base: str | None = None) -> bool:
        doc_id = f"{app_name}_{seccion}_{int(time.time())}"
        if id_base:
            doc_id = id_base
        try:
            self.collection_docs.add(
                documents=[texto_manual],
                metadatas=[{"app": app_name, "seccion": seccion, "timestamp": time.time()}],
                ids=[doc_id],
            )
            logger.info("Indexado: %s - %s", app_name, seccion)
            return True
        except Exception as exc:
            logger.error("Error indexando: %s", exc)
            return False

    def buscar_instrucciones(self, tarea: str, app_name: str, n_resultados: int = 2) -> list | None:
        try:
            resultados = self.collection_docs.query(
                query_texts=[tarea],
                n_results=n_resultados,
                where={"app": app_name},
            )
            if resultados.get("documents") and resultados["documents"][0]:
                return resultados["documents"][0]
            return None
        except Exception as exc:
            logger.error("Error en búsqueda: %s", exc)
            return None

    def registrar_experiencia(self, app_name: str, accion: str, resultado: str, error: str | None = None) -> None:
        exp_id = f"{app_name}_{int(time.time())}"
        doc = f"Acción: {accion}\nResultado: {resultado}\nError: {error or 'ninguno'}"
        self.collection_exp.add(
            documents=[doc],
            metadatas=[{"app": app_name, "resultado": resultado, "timestamp": time.time()}],
            ids=[exp_id],
        )

    def obtener_contexto_manual(self, tarea: str, app_name: str) -> str | None:
        docs = self.buscar_instrucciones(tarea, app_name, n_resultados=1)
        if docs:
            return docs[0]
        return None
