#!/usr/bin/env python3
"""Federated learning client — shares experiences across bars without sharing raw data."""

import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from core.memory.semantic_brain import SemanticBrain

logger = logging.getLogger("FederatedClient")

URA_BASE = Path(__file__).resolve().parent.parent.parent
GLOBAL_WEIGHTS_FILE = URA_BASE / "config" / "global_weights.json"


class FederatedClient:
    """Client for federated learning between multiple bar locations."""

    def __init__(
        self,
        server_url: str = "http://100.123.81.101:8080",
        bar_id: str | None = None,
    ) -> None:
        self.server_url = server_url
        self.bar_id = bar_id or os.getenv("URA_BAR_ID", "bar_default")
        self.brain = SemanticBrain()

    def enviar_experiencias(self) -> bool:
        """Exports recent experiences (last 24h) to the central server.

        Returns:
            True if upload succeeded, False otherwise.
        """
        try:
            todas = self.brain.collection_exp.get()
            experiencias: list[dict[str, Any]] = []
            for i, meta in enumerate(todas.get("metadatas", [])):
                if meta.get("timestamp", 0) > time.time() - 86400:
                    experiencias.append(
                        {
                            "id": todas["ids"][i],
                            "document": todas["documents"][i],
                            "metadata": meta,
                        }
                    )
            data = {"bar_id": self.bar_id, "experiencias": experiencias}
            resp = requests.post(f"{self.server_url}/upload", json=data, timeout=30)
            return resp.status_code == 200
        except Exception as exc:
            logger.error("Error enviando experiencias: %s", exc)
            return False

    def recibir_modelo_global(self) -> bool:
        """Downloads updated global weights from the central server.

        Returns:
            True if download succeeded, False otherwise.
        """
        try:
            resp = requests.get(f"{self.server_url}/model", timeout=30)
            if resp.status_code == 200:
                GLOBAL_WEIGHTS_FILE.parent.mkdir(parents=True, exist_ok=True)
                with open(GLOBAL_WEIGHTS_FILE, "w", encoding="utf-8") as fh:
                    fh.write(resp.text)
                return True
        except Exception as exc:
            logger.error("Error recibiendo modelo global: %s", exc)
        return False

    def aplicar_pesos_globales(self) -> bool:
        """Applies downloaded global weights to local decision-making.

        Returns:
            True if weights were applied, False otherwise.
        """
        if not GLOBAL_WEIGHTS_FILE.exists():
            return False
        try:
            with open(GLOBAL_WEIGHTS_FILE, encoding="utf-8") as fh:
                pesos = json.load(fh)
            logger.info("Pesos globales aplicados: %d reglas", len(pesos))
            return True
        except Exception as exc:
            logger.error("Error aplicando pesos globales: %s", exc)
            return False


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    client = FederatedClient()
    if client.enviar_experiencias():
        logger.info("Experiencias enviadas correctamente")
    if client.recibir_modelo_global():
        logger.info("Modelo global recibido correctamente")
