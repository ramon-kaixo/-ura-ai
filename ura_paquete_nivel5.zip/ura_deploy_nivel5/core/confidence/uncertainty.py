#!/usr/bin/env python3
"""Confidence estimator — calculates action confidence based on manual similarity, history, and episodes."""

import json
import logging
from pathlib import Path
from typing import Dict, List, Tuple

from core.memory.episodic_memory import EpisodicMemory
from core.memory.semantic_brain import SemanticBrain

logger = logging.getLogger("ConfidenceEstimator")

URA_BASE = Path(__file__).resolve().parent.parent.parent
CONFIDENCE_FILE = URA_BASE / "data" / "confidence_history.json"


class ConfidenceEstimator:
    """Estimates confidence for actions based on multiple signals."""

    def __init__(self) -> None:
        self.brain = SemanticBrain()
        self.episodic = EpisodicMemory()
        self.historial_exitos: dict[str, list[int]] = {}
        self._cargar_historial()

    def _cargar_historial(self) -> None:
        """Loads success history from disk."""
        if CONFIDENCE_FILE.exists():
            try:
                with open(CONFIDENCE_FILE, encoding="utf-8") as fh:
                    self.historial_exitos = json.load(fh)
            except Exception as exc:
                logger.error("Error cargando historial: %s", exc)

    def guardar_historial(self) -> None:
        """Saves success history to disk."""
        CONFIDENCE_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(CONFIDENCE_FILE, "w", encoding="utf-8") as fh:
            json.dump(self.historial_exitos, fh, indent=2)

    def calcular_confianza(self, tarea: str, app_name: str) -> float:
        """Calculates confidence score between 0 and 1.

        Args:
            tarea: Task description.
            app_name: Application name.

        Returns:
            Confidence score (0.0 to 1.0).
        """
        docs = self.brain.buscar_instrucciones(tarea, app_name, n_resultados=1)
        similitud_manual = 0.8 if docs else 0.5

        historico = self.historial_exitos.get(tarea, [0, 0])
        tasa_exito = historico[0] / max(1, historico[1])

        episodios = self.episodic.recordar_sucesos(tarea, n_resultados=3)
        similitud_episodios = 0.0
        for ep in episodios:
            if "exito" in ep.lower() or "ok" in ep.lower():
                similitud_episodios += 0.3
        similitud_episodios = min(similitud_episodios, 1.0)

        confianza = 0.4 * similitud_manual + 0.4 * tasa_exito + 0.2 * similitud_episodios
        return min(max(confianza, 0.0), 1.0)

    def registrar_resultado(self, tarea: str, exito: bool) -> None:
        """Records the outcome of a task execution.

        Args:
            tarea: Task description.
            exito: Whether the task succeeded.
        """
        if tarea not in self.historial_exitos:
            self.historial_exitos[tarea] = [0, 0]
        if exito:
            self.historial_exitos[tarea][0] += 1
        self.historial_exitos[tarea][1] += 1
        self.guardar_historial()
