#!/usr/bin/env python3
"""Swarm orchestrator — coordinates buzos via Redis message bus for emergent behavior."""

import json
import logging
import subprocess
from typing import Any, Dict

from core.message_bus import MessageBus

logger = logging.getLogger("SwarmOrchestrator")


class SwarmOrchestrator:
    """Orchestrates swarm behavior by routing events to appropriate buzos."""

    def __init__(self) -> None:
        self.bus = MessageBus()
        self.objetivos: dict[str, str] = {}
        self._setup_subscriptions()

    def _setup_subscriptions(self) -> None:
        """Sets up event subscriptions for swarm coordination."""
        self.bus.suscribir("eventos/stock_bajo", self.on_stock_bajo)
        self.bus.suscribir("eventos/cliente_enfadado", self.on_cliente_enfadado)
        self.bus.suscribir("eventos/fallo_red", self.on_fallo_red)
        self.bus.suscribir("eventos/clima_extremo", self.on_clima_extremo)
        logger.info("Suscripciones de orquestador activas")

    def on_stock_bajo(self, mensaje: dict[str, Any]) -> None:
        """Handles low stock events by triggering reordering.

        Args:
            mensaje: Event data with product and quantity info.
        """
        logger.info("Stock bajo detectado: %s", mensaje)
        self.bus.publicar(
            "tareas/reabastecer",
            {
                "producto": mensaje.get("producto"),
                "cantidad": mensaje.get("cantidad"),
            },
        )
        self.bus.publicar("consultas/precios", {"producto": mensaje.get("producto")})

    def on_cliente_enfadado(self, mensaje: dict[str, Any]) -> None:
        """Handles angry customer events by triggering courtesy actions.

        Args:
            mensaje: Event data with table and context info.
        """
        logger.info("Cliente enfadado en mesa %s", mensaje.get("mesa"))
        self.bus.publicar(
            "acciones/cortesia",
            {
                "mesa": mensaje.get("mesa"),
                "tipo": "cafe",
            },
        )

    def on_fallo_red(self, mensaje: dict[str, Any]) -> None:
        """Handles network failure events by triggering auto-repair.

        Args:
            mensaje: Event data (unused).
        """
        logger.info("Orden de reparacion de red recibida")
        script = "scripts/network_autorepair.sh"
        subprocess.Popen(["bash", script], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def on_clima_extremo(self, mensaje: dict[str, Any]) -> None:
        """Handles extreme weather events by adjusting operations.

        Args:
            mensaje: Weather event data.
        """
        logger.info("Clima extremo detectado: %s", mensaje)
        precipitacion = mensaje.get("precipitacion", 0)
        if precipitacion > 10:
            self.bus.publicar("acciones/ajuste_terrazas", {"accion": "cerrar"})
        elif precipitacion < 2:
            self.bus.publicar("acciones/ajuste_terrazas", {"accion": "abrir"})

    def lanzar_tarea_compleja(self, objetivo: str) -> None:
        """Decomposes a complex goal into sub-goals and publishes them.

        Args:
            objetivo: High-level goal description.
        """
        prompt = (
            f"Descompone este objetivo en subobjetivos atomicos: {objetivo}. "
            f"Devuelve JSON lista de strings."
        )
        try:
            import requests

            gx10_url = "http://100.127.206.86:11434/api/generate"
            resp = requests.post(
                gx10_url,
                json={"model": "qwen3:32b", "prompt": prompt, "stream": False},
                timeout=30,
            )
            respuesta = resp.json().get("response", "[]")
            subobjetivos = json.loads(respuesta)
            for sub in subobjetivos:
                self.bus.publicar("tareas/atomicas", {"subobjetivo": sub, "origen": objetivo})
        except Exception as exc:
            logger.error("Error descomponiendo objetivo: %s", exc)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    orchestrator = SwarmOrchestrator()
    logger.info("Orquestador de enjambre iniciado")
    import time

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("Orquestador detenido")
