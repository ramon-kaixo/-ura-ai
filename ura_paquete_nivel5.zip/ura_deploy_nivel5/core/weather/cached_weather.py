#!/usr/bin/env python3
"""Cached weather module with ARIMA prediction fallback."""

import json
import logging
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List

import requests

logger = logging.getLogger("CachedWeather")

URA_BASE = Path(__file__).resolve().parent.parent.parent
DATA_DIR = URA_BASE / "data"
CACHE_FILE = DATA_DIR / "weather_cache.json"
FORECAST_FILE = DATA_DIR / "weather_forecast.json"


class CachedWeather:
    """Caches weather data and predicts using ARIMA when API is unavailable."""

    def __init__(self) -> None:
        self.cache: dict[str, Any] = {}
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self._load_cache()

    def _load_cache(self) -> None:
        """Loads weather cache from disk."""
        if CACHE_FILE.exists():
            try:
                with open(CACHE_FILE, encoding="utf-8") as fh:
                    self.cache = json.load(fh)
            except Exception as exc:
                logger.error("Error cargando cache clima: %s", exc)

    def _save_cache(self) -> None:
        """Saves weather cache to disk."""
        with open(CACHE_FILE, "w", encoding="utf-8") as fh:
            json.dump(self.cache, fh, indent=2)

    def get_weather(self, lat: float = 42.8125, lon: float = -1.6458) -> dict[str, Any]:
        """Gets current weather data, using cache or API with ARIMA fallback.

        Args:
            lat: Latitude (default: Pamplona).
            lon: Longitude (default: Pamplona).

        Returns:
            Dictionary with weather data.
        """
        today = datetime.now().strftime("%Y-%m-%d")
        if today in self.cache:
            return self.cache[today]

        try:
            url = (
                f"https://api.open-meteo.com/v1/forecast?"
                f"latitude={lat}&longitude={lon}"
                f"&daily=precipitation_sum,temperature_2m_max"
                f"&timezone=Europe/Madrid"
            )
            resp = requests.get(url, timeout=5)
            data = resp.json()
            daily = data["daily"]
            result: dict[str, Any] = {
                "precipitacion": daily["precipitation_sum"][0],
                "temp_max": daily["temperature_2m_max"][0],
                "fecha": today,
                "fuente": "api",
            }
            self.cache[today] = result
            self._save_cache()
            return result
        except Exception as exc:
            logger.warning("API meteorologica fallo: %s. Usando prediccion.", exc)
            return self._predecir_clima()

    def _predecir_clima(self) -> dict[str, Any]:
        """Predicts weather using historical data with simple averaging.

        Returns:
            Dictionary with predicted weather data.
        """
        historial: list[float] = []
        for datos in self.cache.values():
            if "precipitacion" in datos and isinstance(datos["precipitacion"], (int, float)):
                historial.append(float(datos["precipitacion"]))

        pred = 0.0
        if len(historial) >= 7:
            try:
                from statsmodels.tsa.arima.model import ARIMA

                model = ARIMA(historial, order=(1, 1, 1))
                model_fit = model.fit()
                pred = float(max(0, model_fit.forecast(steps=1)[0]))
            except Exception:
                pred = sum(historial[-7:]) / 7

        today = datetime.now().strftime("%Y-%m-%d")
        result: dict[str, Any] = {
            "precipitacion": pred,
            "temp_max": 20,
            "fecha": today,
            "fuente": "arima_prediccion",
        }
        self.cache[today] = result
        self._save_cache()
        return result

    def get_forecast_week(self) -> list[dict[str, Any]]:
        """Gets 7-day weather forecast.

        Returns:
            List of daily forecast dictionaries.
        """
        forecast: list[dict[str, Any]] = []
        for i in range(1, 8):
            future_date = (datetime.now() + timedelta(days=i)).strftime("%Y-%m-%d")
            if future_date in self.cache:
                forecast.append(self.cache[future_date])
            else:
                valores = [
                    v["precipitacion"]
                    for v in self.cache.values()
                    if isinstance(v.get("precipitacion"), (int, float))
                ]
                avg = sum(valores[-7:]) / 7 if len(valores) >= 7 else 0
                forecast.append(
                    {
                        "precipitacion": avg,
                        "temp_max": 20,
                        "fecha": future_date,
                        "fuente": "promedio",
                    }
                )
        return forecast


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    weather = CachedWeather()
    today = weather.get_weather()
    logger.info("Clima actual: %s", today)
