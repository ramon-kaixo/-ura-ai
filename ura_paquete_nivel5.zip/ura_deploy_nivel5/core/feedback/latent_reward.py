#!/usr/bin/env python3
"""Latent reward module — tracks delayed feedback for actions."""

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict

from core.memory.episodic_memory import EpisodicMemory

logger = logging.getLogger("LatentReward")

URA_BASE = Path(__file__).resolve().parent.parent.parent
DATA_DIR = URA_BASE / "data"
PENDING_FILE = DATA_DIR / "pending_actions.json"


class LatentReward:
    """Tracks actions and evaluates their delayed rewards based on later metrics."""

    def __init__(self) -> None:
        self.memoria = EpisodicMemory()
        self.pending: dict[str, Any] = {}
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self._load_pending()

    def _load_pending(self) -> None:
        """Loads pending actions from disk."""
        if PENDING_FILE.exists():
            try:
                with open(PENDING_FILE, encoding="utf-8") as fh:
                    self.pending = json.load(fh)
            except Exception as exc:
                logger.error("Error cargando acciones pendientes: %s", exc)

    def _save_pending(self) -> None:
        """Saves pending actions to disk."""
        with open(PENDING_FILE, "w", encoding="utf-8") as fh:
            json.dump(self.pending, fh, indent=2)

    def registrar_accion(self, accion_id: str, descripcion: str, contexto: dict[str, Any]) -> None:
        """Registers an action for later reward evaluation.

        Args:
            accion_id: Unique identifier for the action.
            descripcion: Human-readable description.
            contexto: Contextual data about the action.
        """
        self.pending[accion_id] = {
            "descripcion": descripcion,
            "timestamp": time.time(),
            "contexto": contexto,
        }
        self._save_pending()

    def evaluar_recompensa(self, accion_id: str, metricas: dict[str, float]) -> None:
        """Evaluates the delayed reward for a previously registered action.

        Args:
            accion_id: Unique identifier of the action.
            metricas: Dictionary with metrics like tiempo_estadia, ventas, repeticion_visita.
        """
        if accion_id not in self.pending:
            logger.warning("Accion %s no encontrada", accion_id)
            return

        accion = self.pending.pop(accion_id)
        self._save_pending()

        recompensa = 0.0
        if "tiempo_estadia" in metricas:
            recompensa += min(metricas["tiempo_estadia"] / 30, 1.0) * 0.4
        if "ventas" in metricas:
            recompensa += (metricas["ventas"] / 100) * 0.4
        if "repeticion_visita" in metricas:
            recompensa += metricas["repeticion_visita"] * 0.2
        recompensa = min(recompensa, 1.0)

        desc = f"Accion: {accion['descripcion']} - Recompensa: {recompensa:.2f}"
        self.memoria.registrar_suceso(
            desc,
            {
                "recompensa": recompensa,
                "contexto": accion["contexto"],
                "metricas": metricas,
            },
        )

        try:
            from core.confidence.uncertainty import ConfidenceEstimator

            conf = ConfidenceEstimator()
            conf.cargar_historial()
            if recompensa > 0.7:
                conf.registrar_resultado(accion["descripcion"], True)
            elif recompensa < 0.3:
                conf.registrar_resultado(accion["descripcion"], False)
            conf.guardar_historial()
        except ImportError:
            pass

        logger.info("Recompensa registrada para %s: %.2f", accion_id, recompensa)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    lr = LatentReward()
    test_id = "test_001"
    lr.registrar_accion(test_id, "Ofrecer cafe cortesia", {"mesa": 5})
    lr.evaluar_recompensa(test_id, {"tiempo_estadia": 25, "ventas": 45, "repeticion_visita": 1})
