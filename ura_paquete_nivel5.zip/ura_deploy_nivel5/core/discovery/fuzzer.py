#!/usr/bin/env python3
"""UI Fuzzer — systematically explores application interfaces and builds navigation graphs."""

import json
import logging
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import pyautogui

from core.memory.semantic_brain import SemanticBrain

logger = logging.getLogger("Fuzzer")

URA_BASE = Path(__file__).resolve().parent.parent.parent
DATA_DIR = URA_BASE / "data"
UI_GRAPH_FILE = DATA_DIR / "ui_graph.json"


class UIFuzzer:
    """Systematically explores UI elements and builds a state transition graph."""

    def __init__(self) -> None:
        self.estados_visitados: set[int] = set()
        self.grafo: dict[int, dict[str, Any]] = {}
        self.brain = SemanticBrain()

    def get_ui_state_hash(self) -> int:
        """Generates a hash of the current UI state.

        Returns:
            Integer hash representing the current UI state.
        """
        screenshot = pyautogui.screenshot()
        return hash(screenshot.tobytes())

    def explorar_aplicacion(
        self,
        app_path: str | None = None,
        tiempo_maximo: int = 300,
    ) -> dict[int, dict[str, Any]]:
        """Explores an application by interacting with UI elements.

        Args:
            app_path: Optional path to launch the application.
            tiempo_maximo: Maximum exploration time in seconds.

        Returns:
            Dictionary representing the UI navigation graph.
        """
        if app_path:
            import subprocess

            subprocess.run(["open", app_path], check=False)
            time.sleep(5)

        start_time = time.time()
        while time.time() - start_time < tiempo_maximo:
            estado_actual = self.get_ui_state_hash()
            if estado_actual in self.estados_visitados:
                acciones_no_probadas = self._obtener_acciones_no_probadas(estado_actual)
                if not acciones_no_probadas:
                    break
                target = acciones_no_probadas[0]
            else:
                elementos = self._obtener_elementos_interactivos()
                self.estados_visitados.add(estado_actual)
                self.grafo[estado_actual] = {"elementos": elementos, "transiciones": {}}
                if not elementos:
                    break
                target = elementos[0]

            before_state = self.get_ui_state_hash()
            exito = self._hacer_clic(target)
            time.sleep(2)
            after_state = self.get_ui_state_hash()
            if before_state != after_state and before_state in self.grafo:
                self.grafo[before_state]["transiciones"][target] = after_state

            self.brain.indexar_manual(
                "fuzzing",
                f"click en {target} desde estado {before_state}",
                f"transicion_{before_state}",
            )

        self._guardar_grafo()
        return self.grafo

    def _obtener_elementos_interactivos(self) -> list[str]:
        """Returns a list of interactive element labels.

        Returns:
            List of button/menu labels found in the current UI state.
        """
        try:
            import subprocess

            r = subprocess.run(
                [
                    "osascript",
                    "-e",
                    'tell application "System Events" to get title of every button of every window of (first process whose frontmost is true)',
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if r.stdout.strip():
                botones = [b.strip().strip('"') for b in r.stdout.split(",") if b.strip()]
                return list(set(botones))[:20]
        except Exception:
            pass
        return []

    def _obtener_acciones_no_probadas(self, estado: int) -> list[str]:
        """Returns actions not yet tried from a given state.

        Args:
            estado: The state hash to check.

        Returns:
            List of untried action targets.
        """
        acciones_realizadas = set(self.grafo.get(estado, {}).get("transiciones", {}).keys())
        todos_elementos = set(self.grafo.get(estado, {}).get("elementos", []))
        return list(todos_elementos - acciones_realizadas)

    def _hacer_clic(self, target: str) -> bool:
        """Attempts to click on a UI element by text label.

        Args:
            target: Text label of the element to click.

        Returns:
            True if click was attempted, False otherwise.
        """
        try:
            import subprocess

            r = subprocess.run(
                [
                    "osascript",
                    "-e",
                    f'tell application "System Events" to click button "{target}" of window 1 of (first process whose frontmost is true)',
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )
            return r.returncode == 0
        except Exception:
            return False

    def _guardar_grafo(self) -> None:
        """Saves the UI navigation graph to disk."""
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        grafo_serializable: dict[str, Any] = {}
        for k, v in self.grafo.items():
            grafo_serializable[str(k)] = {
                "elementos": v["elementos"],
                "transiciones": {str(k2): str(v2) for k2, v2 in v["transiciones"].items()},
            }
        with open(UI_GRAPH_FILE, "w", encoding="utf-8") as fh:
            json.dump(grafo_serializable, fh, indent=2)
        logger.info("Grafo de UI guardado con %d estados", len(self.grafo))


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    fuzzer = UIFuzzer()
    fuzzer.explorar_aplicacion(tiempo_maximo=120)
